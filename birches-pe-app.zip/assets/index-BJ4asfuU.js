(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))e(a);new MutationObserver(a=>{for(const n of a)if(n.type==="childList")for(const s of n.addedNodes)s.tagName==="LINK"&&s.rel==="modulepreload"&&e(s)}).observe(document,{childList:!0,subtree:!0});function i(a){const n={};return a.integrity&&(n.integrity=a.integrity),a.referrerPolicy&&(n.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?n.credentials="include":a.crossOrigin==="anonymous"?n.credentials="omit":n.credentials="same-origin",n}function e(a){if(a.ep)return;a.ep=!0;const n=i(a);fetch(a.href,n)}})();class m{activities=[];standards=[];constructor(){this.loadData()}async loadData(){try{const[t,i]=await Promise.all([fetch("/data/activities.json"),fetch("/data/standards.json")]);this.activities=await t.json(),this.standards=await i.json()}catch(t){console.error("Failed to load data:",t)}}async generate(t){return this.activities.length===0&&await this.loadData(),{id:this.generateId(),title:this.generateTitle(t),overview:this.generateOverview(t),goals:this.generateGoals(t),lessons:this.generateLessons(t),metadata:{gradeLevel:t.gradeLevel,duration:t.duration,environment:t.environment,standards:t.standards,equipmentLevel:t.equipmentLevel||"standard"},createdAt:new Date().toISOString()}}generateId(){return`pb_${Date.now()}_${Math.random().toString(36).substr(2,9)}`}generateTitle(t){const i=t.gradeLevel,e=this.getStandardNames(t.standards);return`${i} ${t.environment==="outdoor"?"Outdoor":"Indoor"} PE: ${e.join(" & ")}`}generateOverview(t){const i=t.duration===60?"2 weeks":"1 week",e=this.getStandardNames(t.standards);return`This ${i} playbook for grades ${t.gradeLevel} focuses on ${e.join(", ")} in an ${t.environment} setting. Each lesson builds progressively on skills while maintaining engagement through varied activities.`}generateGoals(t){const i=[];return t.standards.forEach(e=>{const a=this.standards.find(n=>n.id===e);a&&i.push(`Develop ${a.name.toLowerCase()} skills`)}),t.gradeLevel==="K-2"?(i.push("Build fundamental movement patterns"),i.push("Develop spatial awareness and body control")):t.gradeLevel==="3-5"?(i.push("Refine movement skills and combinations"),i.push("Introduce strategic thinking in activities")):(i.push("Apply skills in complex game situations"),i.push("Develop leadership and teamwork abilities")),t.activityPreferences?.teamBased&&i.push("Foster collaboration and communication"),t.activityPreferences?.competitive&&i.push("Build healthy competition and sportsmanship"),t.activityPreferences?.creative&&i.push("Encourage creative movement and expression"),i.slice(0,5)}generateLessons(t){const i=t.duration===60?10:5,e=[];for(let a=0;a<i;a++)e.push(this.generateLesson(t,a+1));return e}generateLesson(t,i){const e=this.filterActivities("warmup",t),a=this.filterActivities("main",t),n=this.filterActivities("skill",t),s=this.selectRandom(e),o=this.selectRandom(a),l=this.selectMultiple(n,3);return{title:`Lesson ${i}: ${this.getLessonFocus(t,i)}`,warmUp:{description:s?.description||"Dynamic stretching and light jogging around the space",duration:Math.floor(t.duration*.15),equipment:s?.equipment||[]},skillFocus:{description:this.generateSkillDescription(l,t),duration:Math.floor(t.duration*.25),skills:l.map(d=>d.name)},mainActivity:{name:o?.name||"Team Activity",description:o?.description||"Engaging group activity focusing on lesson objectives",duration:Math.floor(t.duration*.4),rules:o?.rules||["Respect all participants","Follow safety guidelines","Rotate positions fairly","Encourage teammates"],equipment:o?.equipment||["cones","balls"]},differentiation:{easier:this.generateEasierModification(t,o),harder:this.generateHarderModification(t,o)},closure:{description:"Group reflection circle discussing today's achievements and challenges",duration:Math.floor(t.duration*.1),reflection:this.generateReflectionQuestion(t,i)},assessment:{formative:"Teacher observation of skill execution and peer interaction",summative:"Skill demonstration and self-assessment rubric"},safety:this.generateSafetyConsiderations(t,o),socialEmotional:this.generateSELFocus(i)}}filterActivities(t,i){return this.activities.filter(e=>!(t==="warmup"&&e.type!=="warmup"||t==="main"&&!["game","activity"].includes(e.type)||t==="skill"&&e.type!=="skill"||e.gradeLevel&&!e.gradeLevel.includes(i.gradeLevel)||e.environment&&e.environment!==i.environment||i.equipmentLevel==="minimal"&&e.equipment?.length>2||i.equipmentLevel==="standard"&&e.equipment?.length>5))}selectRandom(t){return t.length===0?null:t[Math.floor(Math.random()*t.length)]}selectMultiple(t,i){const e=[...t].sort(()=>.5-Math.random());return e.slice(0,Math.min(i,e.length))}getStandardNames(t){return t.map(i=>this.standards.find(a=>a.id===i)?.name||i)}getLessonFocus(t,i){const e=["Building Foundations","Skill Development","Application Practice","Game Strategies","Assessment & Review"],a=e.length;return e[(i-1)%a]}generateSkillDescription(t,i){return t.length===0?"Practice fundamental movement skills through structured activities":`Students will practice ${t.map(a=>a.name).join(", ")} through progressive drills and partner activities`}generateEasierModification(t,i){const e=["Reduce distance or playing area","Allow additional touches or attempts","Use lighter or softer equipment","Pair with a skilled partner for support","Simplify rules or scoring system"];return this.selectRandom(e)||e[0]}generateHarderModification(t,i){const e=["Increase distance or expand playing area","Add time constraints or speed requirements","Introduce defensive pressure","Require specific techniques or form","Add complex scoring or bonus challenges"];return this.selectRandom(e)||e[0]}generateReflectionQuestion(t,i){const e=["What skill did you improve most today?","How did you help your teammates succeed?","What strategy worked best in the main activity?","What would you do differently next time?","How did you show good sportsmanship today?"];return e[(i-1)%e.length]}generateSafetyConsiderations(t,i){const e=[];return t.environment==="outdoor"&&(e.push("Check playing surface for hazards"),e.push("Ensure adequate hydration breaks")),i?.equipment?.includes("balls")&&e.push("Maintain safe spacing during throwing activities"),e.push("Proper warm-up before intense activity"),e.push("Monitor for signs of fatigue or overexertion"),e.slice(0,3)}generateSELFocus(t){const i=["Building confidence through skill mastery","Developing empathy by supporting classmates","Practicing emotional regulation during competition","Fostering resilience through challenging activities","Cultivating teamwork and communication skills"];return i[(t-1)%i.length]}}class u{STORAGE_KEY="birches_pe_playbooks";SETTINGS_KEY="birches_pe_settings";MAX_PLAYBOOKS=10;async init(){if(localStorage.getItem(this.STORAGE_KEY)||localStorage.setItem(this.STORAGE_KEY,JSON.stringify([])),!localStorage.getItem(this.SETTINGS_KEY)){const t={theme:"light",defaultDuration:45,defaultParticipants:25,favoriteActivities:[],aiProvider:null,autoSave:!0,offlineMode:!0};localStorage.setItem(this.SETTINGS_KEY,JSON.stringify(t))}}async savePlaybook(t){const i=await this.getAllPlaybooks(),e={...t,name:t.title,tags:[],favorite:!1};i.unshift(e);const a=i.slice(0,this.MAX_PLAYBOOKS);localStorage.setItem(this.STORAGE_KEY,JSON.stringify(a))}async getAllPlaybooks(){const t=localStorage.getItem(this.STORAGE_KEY);if(!t)return[];try{return JSON.parse(t)}catch{return[]}}async getPlaybook(t){return(await this.getAllPlaybooks()).find(e=>e.id===t)||null}async deletePlaybook(t){const e=(await this.getAllPlaybooks()).filter(a=>a.id!==t);localStorage.setItem(this.STORAGE_KEY,JSON.stringify(e))}async updatePlaybook(t,i){const e=await this.getAllPlaybooks(),a=e.findIndex(n=>n.id===t);a!==-1&&(e[a]={...e[a],...i,modifiedAt:new Date().toISOString()},localStorage.setItem(this.STORAGE_KEY,JSON.stringify(e)))}async getSettings(){const t=localStorage.getItem(this.SETTINGS_KEY);if(!t)return await this.init(),this.getSettings();try{return JSON.parse(t)}catch{return await this.init(),this.getSettings()}}async updateSettings(t){const e={...await this.getSettings(),...t};localStorage.setItem(this.SETTINGS_KEY,JSON.stringify(e))}async clearAll(){localStorage.removeItem(this.STORAGE_KEY),localStorage.removeItem(this.SETTINGS_KEY),await this.init()}async exportData(){const t=await this.getAllPlaybooks(),i=await this.getSettings();return JSON.stringify({version:"1.0",exportDate:new Date().toISOString(),playbooks:t,settings:i},null,2)}async importData(t){try{const i=JSON.parse(t);i.playbooks&&localStorage.setItem(this.STORAGE_KEY,JSON.stringify(i.playbooks)),i.settings&&localStorage.setItem(this.SETTINGS_KEY,JSON.stringify(i.settings))}catch{throw new Error("Invalid import data format")}}}class p{async generate(t,i){throw new Error("AI generation not yet implemented. Please use deterministic mode.")}}class v{async toPdf(t){window.print()}async toDocx(t){const i=this.generateDocxContent(t);return new Blob([i],{type:"application/vnd.openxmlformats-officedocument.wordprocessingml.document"})}async toMarkdown(t){const i=this.generateMarkdown(t);return new Blob([i],{type:"text/markdown"})}async toCsv(t){const i=this.generateCsv(t);return new Blob([i],{type:"text/csv"})}generateDocxContent(t){let i=`${t.title}

`;return i+=`Grade Level: ${t.metadata.gradeLevel}
`,i+=`Duration: ${t.metadata.duration} minutes
`,i+=`Environment: ${t.metadata.environment}

`,i+=`Overview:
${t.overview}

`,i+=`Goals:
${t.goals.map(e=>`- ${e}`).join(`
`)}

`,t.lessons.forEach((e,a)=>{i+=`
Lesson ${a+1}: ${e.title}
`,i+=`
Warm-up (${e.warmUp.duration} min):
${e.warmUp.description}
`,i+=`
Skill Focus (${e.skillFocus.duration} min):
${e.skillFocus.description}
`,i+=`Skills: ${e.skillFocus.skills.join(", ")}
`,i+=`
Main Activity (${e.mainActivity.duration} min): ${e.mainActivity.name}
`,i+=`${e.mainActivity.description}
`,i+=`Rules:
${e.mainActivity.rules.map(n=>`- ${n}`).join(`
`)}
`,i+=`
Differentiation:
`,i+=`Easier: ${e.differentiation.easier}
`,i+=`Harder: ${e.differentiation.harder}
`,i+=`
Closure (${e.closure.duration} min):
${e.closure.description}
`,i+=`Reflection: ${e.closure.reflection}
`,i+=`
Assessment:
`,i+=`Formative: ${e.assessment.formative}
`,i+=`Summative: ${e.assessment.summative}
`,e.safety.length>0&&(i+=`
Safety:
${e.safety.map(n=>`- ${n}`).join(`
`)}
`),e.socialEmotional&&(i+=`
Social-Emotional Learning:
${e.socialEmotional}
`)}),i}generateMarkdown(t){let i=`# ${t.title}

`;return i+=`## Metadata

`,i+=`- **Grade Level:** ${t.metadata.gradeLevel}
`,i+=`- **Duration:** ${t.metadata.duration} minutes
`,i+=`- **Environment:** ${t.metadata.environment}
`,i+=`- **Standards:** ${t.metadata.standards.join(", ")}

`,i+=`## Overview

${t.overview}

`,i+=`## Goals

${t.goals.map(e=>`- ${e}`).join(`
`)}

`,t.lessons.forEach((e,a)=>{i+=`## Lesson ${a+1}: ${e.title}

`,i+=`### Warm-up (${e.warmUp.duration} min)

`,i+=`${e.warmUp.description}

`,e.warmUp.equipment.length>0&&(i+=`**Equipment:** ${e.warmUp.equipment.join(", ")}

`),i+=`### Skill Focus (${e.skillFocus.duration} min)

`,i+=`${e.skillFocus.description}

`,i+=`**Skills:** ${e.skillFocus.skills.join(", ")}

`,i+=`### Main Activity (${e.mainActivity.duration} min): ${e.mainActivity.name}

`,i+=`${e.mainActivity.description}

`,i+=`**Rules:**
${e.mainActivity.rules.map(n=>`- ${n}`).join(`
`)}

`,e.mainActivity.equipment.length>0&&(i+=`**Equipment:** ${e.mainActivity.equipment.join(", ")}

`),i+=`### Differentiation

`,i+=`- **Easier:** ${e.differentiation.easier}
`,i+=`- **Harder:** ${e.differentiation.harder}

`,i+=`### Closure (${e.closure.duration} min)

`,i+=`${e.closure.description}

`,i+=`**Reflection:** ${e.closure.reflection}

`,i+=`### Assessment

`,i+=`- **Formative:** ${e.assessment.formative}
`,i+=`- **Summative:** ${e.assessment.summative}

`,e.safety.length>0&&(i+=`### Safety Considerations

`,i+=`${e.safety.map(n=>`- ${n}`).join(`
`)}

`),e.socialEmotional&&(i+=`### Social-Emotional Learning

`,i+=`${e.socialEmotional}

`)}),i}generateCsv(t){const i=[];return i.push(["Playbook Title",t.title]),i.push(["Grade Level",t.metadata.gradeLevel]),i.push(["Duration",t.metadata.duration.toString()]),i.push(["Environment",t.metadata.environment]),i.push(["Standards",t.metadata.standards.join("; ")]),i.push([]),i.push(["Lesson","Component","Duration","Description","Details"]),t.lessons.forEach((e,a)=>{i.push([`Lesson ${a+1}`,"Warm-up",e.warmUp.duration.toString(),e.warmUp.description,e.warmUp.equipment.join(", ")]),i.push(["","Skill Focus",e.skillFocus.duration.toString(),e.skillFocus.description,e.skillFocus.skills.join(", ")]),i.push(["","Main Activity",e.mainActivity.duration.toString(),e.mainActivity.name,e.mainActivity.description]),i.push(["","Closure",e.closure.duration.toString(),e.closure.description,e.closure.reflection])}),i.map(e=>e.map(a=>`"${(a||"").replace(/"/g,'""')}"`).join(",")).join(`
`)}}class g{container;generator;aiGenerator;store;exportManager;currentPlaybook=null;useAI=!1;constructor(t){this.container=t,this.generator=new m,this.aiGenerator=new p,this.store=new u,this.exportManager=new v,this.init()}async init(){await this.store.init(),this.render(),this.attachEventListeners(),this.loadSettings()}render(){this.container.innerHTML=`
      <div class="generator-container">
        <nav class="nav glass">
          <div class="container">
            <div class="nav-container">
              <a href="/" class="nav-logo">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M12 2L2 7l10 5 10-5-10-5z"/>
                  <path d="M2 17l10 5 10-5"/>
                  <path d="M2 12l10 5 10-5"/>
                </svg>
                <span>Birches PE Playbook</span>
              </a>
              <div class="nav-menu">
                <button class="btn btn-ghost btn-icon" id="theme-toggle" aria-label="Toggle theme">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="5"/>
                    <line x1="12" y1="1" x2="12" y2="3"/>
                    <line x1="12" y1="21" x2="12" y2="23"/>
                    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/>
                    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
                    <line x1="1" y1="12" x2="3" y2="12"/>
                    <line x1="21" y1="12" x2="23" y2="12"/>
                    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/>
                    <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
                  </svg>
                </button>
                <button class="btn btn-ghost btn-icon" id="settings-btn" aria-label="Settings">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="3"/>
                    <path d="M12 1v6m0 6v6m3.22-10.22l4.24-4.24M5.54 5.54L1.3 1.3m17.16 17.16l-4.24-4.24M5.54 18.46L1.3 22.7M23 12h-6m-6 0H1m10.22 3.22l-4.24 4.24M18.46 5.54L22.7 1.3m-4.24 17.16l4.24 4.24M5.54 5.54L1.3 9.78"/>
                  </svg>
                </button>
                <button class="btn btn-ghost btn-icon" id="library-btn" aria-label="Library">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
                    <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
                  </svg>
                </button>
              </div>
            </div>
          </div>
        </nav>

        <div class="container mt-4">
          <div class="grid grid-cols-3 gap-4">
            <!-- Input Form -->
            <div class="card glass">
              <h2>Create Playbook</h2>
              
              <form id="generator-form">
                <div class="form-group">
                  <label class="form-label">Grade Level</label>
                  <select class="form-select" name="gradeLevel" required>
                    <option value="">Select grade band</option>
                    <option value="K-2">K-2</option>
                    <option value="3-5">3-5</option>
                    <option value="6-8">6-8</option>
                  </select>
                </div>

                <div class="form-group">
                  <label class="form-label">Duration (minutes)</label>
                  <select class="form-select" name="duration" required>
                    <option value="">Select duration</option>
                    <option value="30">30 minutes</option>
                    <option value="45">45 minutes</option>
                    <option value="60">60 minutes</option>
                  </select>
                </div>

                <div class="form-group">
                  <label class="form-label">Environment</label>
                  <div class="flex gap-2">
                    <label class="form-radio">
                      <input type="radio" name="environment" value="indoor" required>
                      <span>Indoor</span>
                    </label>
                    <label class="form-radio">
                      <input type="radio" name="environment" value="outdoor" required>
                      <span>Outdoor</span>
                    </label>
                  </div>
                </div>

                <div class="form-group">
                  <label class="form-label">PE Standards (select 1-3)</label>
                  <div id="standards-checkboxes" class="standards-grid">
                    <!-- Populated dynamically -->
                  </div>
                </div>

                <div class="form-group">
                  <label class="form-label">Equipment Level</label>
                  <select class="form-select" name="equipmentLevel">
                    <option value="minimal">Minimal (cones, balls)</option>
                    <option value="standard">Standard (+ nets, hoops)</option>
                    <option value="full">Full (all equipment)</option>
                  </select>
                </div>

                <div class="form-group">
                  <label class="form-label">Fun Factors</label>
                  <label class="form-checkbox">
                    <input type="checkbox" name="teamBased" value="true">
                    <span>Team-based</span>
                  </label>
                  <label class="form-checkbox">
                    <input type="checkbox" name="competitive" value="true">
                    <span>Competitive</span>
                  </label>
                  <label class="form-checkbox">
                    <input type="checkbox" name="creative" value="true">
                    <span>Creative/Imaginative</span>
                  </label>
                </div>

                <div class="form-group">
                  <label class="form-checkbox">
                    <input type="checkbox" id="use-ai" ${this.useAI?"checked":""}>
                    <span>Use AI Generation (Claude/OpenAI)</span>
                  </label>
                </div>

                <div class="flex gap-2">
                  <button type="submit" class="btn btn-primary flex-1">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
                    </svg>
                    Generate Playbook
                  </button>
                  <button type="button" id="quick-preset" class="btn btn-secondary">
                    Quick
                  </button>
                </div>
              </form>
            </div>

            <!-- Output Display -->
            <div class="card glass" style="grid-column: span 2;">
              <div class="playbook-header flex justify-between items-center mb-3">
                <h2>Generated Playbook</h2>
                <div class="flex gap-2">
                  <button class="btn btn-ghost btn-icon" id="save-btn" disabled aria-label="Save">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
                      <polyline points="17 21 17 13 7 13 7 21"/>
                      <polyline points="7 3 7 8 15 8"/>
                    </svg>
                  </button>
                  <button class="btn btn-ghost btn-icon" id="export-btn" disabled aria-label="Export">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                      <polyline points="7 10 12 15 17 10"/>
                      <line x1="12" y1="15" x2="12" y2="3"/>
                    </svg>
                  </button>
                  <button class="btn btn-ghost btn-icon" id="print-btn" disabled aria-label="Print">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <polyline points="6 9 6 2 18 2 18 9"/>
                      <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/>
                      <rect x="6" y="14" width="12" height="8"/>
                    </svg>
                  </button>
                  <button class="btn btn-ghost btn-icon" id="regenerate-btn" disabled aria-label="Regenerate">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <polyline points="23 4 23 10 17 10"/>
                      <polyline points="1 20 1 14 7 14"/>
                      <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
                    </svg>
                  </button>
                </div>
              </div>

              <div id="playbook-content" class="playbook-content">
                <div class="empty-state text-center p-4">
                  <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" class="mx-auto mb-3 opacity-30">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                    <polyline points="14 2 14 8 20 8"/>
                    <line x1="16" y1="13" x2="8" y2="13"/>
                    <line x1="16" y1="17" x2="8" y2="17"/>
                    <polyline points="10 9 9 9 8 9"/>
                  </svg>
                  <p class="text-muted">Configure options and generate your first playbook</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Settings Modal -->
        <div id="settings-modal" class="modal-overlay">
          <div class="modal">
            <h3>Settings</h3>
            <div class="form-group">
              <label class="form-label">AI Provider</label>
              <select class="form-select" id="ai-provider">
                <option value="anthropic">Anthropic Claude</option>
                <option value="openai">OpenAI GPT-4</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">API Key</label>
              <input type="password" class="form-input" id="api-key" placeholder="sk-...">
              <small class="text-muted">Your key is stored locally and never sent to our servers</small>
            </div>
            <div class="form-group">
              <label class="form-checkbox">
                <input type="checkbox" id="blend-mode">
                <span>Blend Mode (Mix AI + Deterministic)</span>
              </label>
            </div>
            <div class="flex gap-2 justify-end mt-3">
              <button class="btn btn-ghost" id="settings-cancel">Cancel</button>
              <button class="btn btn-primary" id="settings-save">Save Settings</button>
            </div>
          </div>
        </div>

        <!-- Library Modal -->
        <div id="library-modal" class="modal-overlay">
          <div class="modal" style="max-width: 800px;">
            <h3>Saved Playbooks</h3>
            <div id="library-list" class="library-list mt-3">
              <!-- Populated dynamically -->
            </div>
            <div class="flex justify-end mt-3">
              <button class="btn btn-ghost" id="library-close">Close</button>
            </div>
          </div>
        </div>

        <!-- Export Modal -->
        <div id="export-modal" class="modal-overlay">
          <div class="modal">
            <h3>Export Playbook</h3>
            <div class="export-options grid grid-cols-2 gap-2 mt-3">
              <button class="btn btn-secondary" data-format="pdf">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                  <polyline points="14 2 14 8 20 8"/>
                </svg>
                PDF
              </button>
              <button class="btn btn-secondary" data-format="docx">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                  <polyline points="14 2 14 8 20 8"/>
                  <line x1="16" y1="13" x2="8" y2="13"/>
                  <line x1="16" y1="17" x2="8" y2="17"/>
                </svg>
                Word
              </button>
              <button class="btn btn-secondary" data-format="markdown">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                  <path d="M7 11h2l2 4 2-4h2M15 11v6"/>
                </svg>
                Markdown
              </button>
              <button class="btn btn-secondary" data-format="csv">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                  <polyline points="14 2 14 8 20 8"/>
                  <line x1="9" y1="13" x2="15" y2="13"/>
                </svg>
                CSV
              </button>
            </div>
            <div class="flex justify-end mt-3">
              <button class="btn btn-ghost" id="export-cancel">Cancel</button>
            </div>
          </div>
        </div>
      </div>
    `,this.loadStandardsCheckboxes()}async loadStandardsCheckboxes(){const i=await(await fetch("/data/standards.json")).json(),e=document.getElementById("standards-checkboxes");e&&(e.innerHTML=i.map(a=>`
        <label class="form-checkbox">
          <input type="checkbox" name="standards" value="${a.id}">
          <span title="${a.description}">${a.name}</span>
        </label>
      `).join(""))}attachEventListeners(){document.getElementById("generator-form")?.addEventListener("submit",i=>this.handleGenerate(i)),document.getElementById("theme-toggle")?.addEventListener("click",()=>{document.documentElement.toggleAttribute("data-theme"),localStorage.setItem("theme",document.documentElement.hasAttribute("data-theme")?"dark":"light")}),document.getElementById("settings-btn")?.addEventListener("click",()=>{document.getElementById("settings-modal")?.classList.add("active")}),document.getElementById("settings-cancel")?.addEventListener("click",()=>{document.getElementById("settings-modal")?.classList.remove("active")}),document.getElementById("settings-save")?.addEventListener("click",()=>{this.saveSettings()}),document.getElementById("library-btn")?.addEventListener("click",()=>{this.showLibrary()}),document.getElementById("library-close")?.addEventListener("click",()=>{document.getElementById("library-modal")?.classList.remove("active")}),document.getElementById("export-btn")?.addEventListener("click",()=>{document.getElementById("export-modal")?.classList.add("active")}),document.getElementById("export-cancel")?.addEventListener("click",()=>{document.getElementById("export-modal")?.classList.remove("active")}),document.querySelectorAll("[data-format]").forEach(i=>{i.addEventListener("click",e=>{const a=e.currentTarget.dataset.format;a&&this.currentPlaybook&&this.exportPlaybook(a)})}),document.getElementById("save-btn")?.addEventListener("click",()=>this.savePlaybook()),document.getElementById("print-btn")?.addEventListener("click",()=>window.print()),document.getElementById("regenerate-btn")?.addEventListener("click",()=>this.regenerate()),document.getElementById("quick-preset")?.addEventListener("click",()=>{this.applyQuickPreset()}),document.getElementById("use-ai")?.addEventListener("change",i=>{this.useAI=i.target.checked})}async handleGenerate(t){t.preventDefault();const i=t.target,e=new FormData(i),a=e.getAll("standards");if(a.length===0||a.length>3){alert("Please select 1-3 PE standards");return}const n={gradeLevel:e.get("gradeLevel"),duration:parseInt(e.get("duration")),environment:e.get("environment"),standards:a,equipmentLevel:e.get("equipmentLevel"),activityPreferences:{teamBased:e.get("teamBased")==="true",competitive:e.get("competitive")==="true",creative:e.get("creative")==="true"}},s=document.getElementById("playbook-content");s&&(s.innerHTML='<div class="text-center p-4"><div class="spinner"></div><p class="mt-2">Generating playbook...</p></div>');try{let o;if(this.useAI){const l=localStorage.getItem("api-key"),c=localStorage.getItem("ai-provider")||"anthropic";if(!l){alert("Please configure your API key in settings");return}o=await this.aiGenerator.generate(n,{apiKey:l,provider:c})}else o=await this.generator.generate(n);this.currentPlaybook=o,this.renderPlaybook(o),document.querySelectorAll("#save-btn, #export-btn, #print-btn, #regenerate-btn").forEach(l=>{l.removeAttribute("disabled")})}catch(o){console.error("Generation failed:",o),s&&(s.innerHTML='<div class="text-center p-4 text-red-500">Generation failed. Please try again.</div>')}}renderPlaybook(t){const i=document.getElementById("playbook-content");i&&(i.innerHTML=`
      <div class="playbook fade-in">
        <div class="playbook-meta mb-3">
          <h3>${t.title}</h3>
          <div class="flex gap-2 flex-wrap">
            <span class="badge badge-primary">${t.metadata.gradeLevel}</span>
            <span class="badge">${t.metadata.duration} min</span>
            <span class="badge">${t.metadata.environment}</span>
            ${t.metadata.standards.map(e=>`<span class="badge badge-success">${e}</span>`).join("")}
          </div>
        </div>

        <div class="playbook-overview card mb-3">
          <h4>Overview</h4>
          <p>${t.overview}</p>
          <p><strong>Goals:</strong> ${t.goals.join(", ")}</p>
        </div>

        <div class="playbook-lessons">
          ${t.lessons.map((e,a)=>`
            <div class="lesson-block card mb-3">
              <h4>Lesson ${a+1}: ${e.title}</h4>
              
              <div class="lesson-section">
                <h5>Warm-up (${e.warmUp.duration} min)</h5>
                <p>${e.warmUp.description}</p>
                ${e.warmUp.equipment.length>0?`<p><small>Equipment: ${e.warmUp.equipment.join(", ")}</small></p>`:""}
              </div>

              <div class="lesson-section">
                <h5>Skill Focus (${e.skillFocus.duration} min)</h5>
                <p>${e.skillFocus.description}</p>
                <p><strong>Skills:</strong> ${e.skillFocus.skills.join(", ")}</p>
              </div>

              <div class="lesson-section">
                <h5>Main Activity (${e.mainActivity.duration} min)</h5>
                <p><strong>${e.mainActivity.name}</strong></p>
                <p>${e.mainActivity.description}</p>
                <p><strong>Rules:</strong></p>
                <ul>${e.mainActivity.rules.map(n=>`<li>${n}</li>`).join("")}</ul>
                ${e.mainActivity.equipment.length>0?`<p><small>Equipment: ${e.mainActivity.equipment.join(", ")}</small></p>`:""}
              </div>

              <div class="lesson-section">
                <h5>Differentiation</h5>
                <p><strong>Easier:</strong> ${e.differentiation.easier}</p>
                <p><strong>Harder:</strong> ${e.differentiation.harder}</p>
              </div>

              <div class="lesson-section">
                <h5>Closure (${e.closure.duration} min)</h5>
                <p>${e.closure.description}</p>
                <p><strong>Reflection:</strong> ${e.closure.reflection}</p>
              </div>

              <div class="lesson-section">
                <h5>Assessment</h5>
                <p><strong>Formative:</strong> ${e.assessment.formative}</p>
                <p><strong>Summative:</strong> ${e.assessment.summative}</p>
              </div>

              ${e.safety.length>0?`
                <div class="lesson-section">
                  <h5>Safety Considerations</h5>
                  <ul>${e.safety.map(n=>`<li>${n}</li>`).join("")}</ul>
                </div>
              `:""}

              ${e.socialEmotional?`
                <div class="lesson-section">
                  <h5>Social-Emotional Learning</h5>
                  <p>${e.socialEmotional}</p>
                </div>
              `:""}
            </div>
          `).join("")}
        </div>
      </div>
    `)}async savePlaybook(){if(!this.currentPlaybook)return;const t=prompt("Name this playbook:",this.currentPlaybook.title);t&&(this.currentPlaybook.title=t,await this.store.savePlaybook(this.currentPlaybook),alert("Playbook saved!"))}async showLibrary(){const t=await this.store.getAllPlaybooks(),i=document.getElementById("library-list");i&&(t.length===0?i.innerHTML='<p class="text-center text-muted">No saved playbooks yet</p>':i.innerHTML=t.map((e,a)=>`
          <div class="library-item card mb-2 flex justify-between items-center">
            <div>
              <h5>${e.title}</h5>
              <div class="flex gap-2">
                <span class="badge">${e.metadata.gradeLevel}</span>
                <span class="badge">${e.metadata.duration} min</span>
                <span class="badge">${new Date(e.createdAt).toLocaleDateString()}</span>
              </div>
            </div>
            <div class="flex gap-1">
              <button class="btn btn-ghost btn-icon" onclick="generatorUI.loadPlaybook(${a})">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                  <circle cx="12" cy="12" r="3"/>
                </svg>
              </button>
              <button class="btn btn-ghost btn-icon" onclick="generatorUI.deletePlaybook('${e.id}')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="3 6 5 6 21 6"/>
                  <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                </svg>
              </button>
            </div>
          </div>
        `).join("")),document.getElementById("library-modal")?.classList.add("active")}async loadPlaybook(t){const i=await this.store.getAllPlaybooks();i[t]&&(this.currentPlaybook=i[t],this.renderPlaybook(this.currentPlaybook),document.getElementById("library-modal")?.classList.remove("active"),document.querySelectorAll("#save-btn, #export-btn, #print-btn, #regenerate-btn").forEach(e=>{e.removeAttribute("disabled")}))}async deletePlaybook(t){confirm("Delete this playbook?")&&(await this.store.deletePlaybook(t),this.showLibrary())}async exportPlaybook(t){if(this.currentPlaybook)try{switch(t){case"pdf":window.print();break;case"docx":const i=await this.exportManager.toDocx(this.currentPlaybook);this.downloadBlob(i,`${this.currentPlaybook.title}.docx`);break;case"markdown":const e=await this.exportManager.toMarkdown(this.currentPlaybook);this.downloadBlob(e,`${this.currentPlaybook.title}.md`);break;case"csv":const a=await this.exportManager.toCsv(this.currentPlaybook);this.downloadBlob(a,`${this.currentPlaybook.title}.csv`);break}document.getElementById("export-modal")?.classList.remove("active")}catch(i){console.error("Export failed:",i),alert("Export failed. Please try again.")}}downloadBlob(t,i){const e=URL.createObjectURL(t),a=document.createElement("a");a.href=e,a.download=i,a.click(),URL.revokeObjectURL(e)}regenerate(){const t=document.getElementById("generator-form");t&&t.dispatchEvent(new Event("submit"))}applyQuickPreset(){const t=document.getElementById("generator-form");t&&(t.elements.namedItem("gradeLevel").value="3-5",t.elements.namedItem("duration").value="45",t.elements.namedItem("environment").value="indoor",t.elements.namedItem("equipmentLevel").value="standard",t.querySelectorAll('input[name="standards"]').forEach((e,a)=>{e.checked=a<2}))}saveSettings(){const t=document.getElementById("ai-provider")?.value,i=document.getElementById("api-key")?.value,e=document.getElementById("blend-mode")?.checked;t&&localStorage.setItem("ai-provider",t),i&&localStorage.setItem("api-key",i),localStorage.setItem("blend-mode",e?"true":"false"),document.getElementById("settings-modal")?.classList.remove("active")}loadSettings(){localStorage.getItem("theme")==="dark"&&document.documentElement.setAttribute("data-theme","dark");const i=localStorage.getItem("ai-provider");i&&(document.getElementById("ai-provider").value=i);const e=localStorage.getItem("blend-mode")==="true";document.getElementById("blend-mode").checked=e}}window.generatorUI=null;document.addEventListener("DOMContentLoaded",()=>{const r=document.querySelector("#app");if(r){const t=new g(r);window.generatorUI=t}"serviceWorker"in navigator&&navigator.serviceWorker.register("/sw.js").catch(t=>{console.log("Service Worker registration failed:",t)})});
